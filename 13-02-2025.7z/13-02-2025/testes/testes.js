let a = "Olá Mundo";
console.log(a);

let b = 5;
let c = 10;

let d = b + c;

console.log(d);

// comentário
//--------------------------------------------------------------------------------------------

let texto1 = "SENAI ";
let texto2 = "SESI";

let texto3 = texto1 + "-" + texto2;

console.log(texto3);

//--------------------------------------------------------------------------------------------

console.log("somar numero + texto");

console.log(texto1 + d);

//--------------------------------------------------------------------------------------------

let nome = "Kayky";
let sobrenome = "Rodrigues";
let nomeCompleto = nome + " " + sobrenome;

console.log(nomeCompleto);

//--------------------------------------------------------------------------------------------

let quantidade = 7;
let preco = 3.45;
let valorTotal = quantidade * preco;

console.log(valorTotal);

//--------------------------------------------------------------------------------------------

let kitKat = 1;
let alunos = 30;
let pedacos = kitKat / alunos;

console.log(pedacos);

//--------------------------------------------------------------------------------------------

let balas = 35;
let turma = 30;
let sobra = balas % turma;

console.log(sobra);

//--------------------------------------------------------------------------------------------

let populacaoMarilia = 245000;
let taxaCrescimento = 5 / 100;
let anos = 10;
let populacaoFutura = populacaoMarilia * (1 + taxaCrescimento) ** anos

console.log(populacaoFutura)


