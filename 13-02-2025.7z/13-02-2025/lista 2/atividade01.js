let graus = Number(prompt("Insira os graus"))

let F = (graus * 9/5) + 32

console.log("A tmempreratura em Fahrenheit é:", F)