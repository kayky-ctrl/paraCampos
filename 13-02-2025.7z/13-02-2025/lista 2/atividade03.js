let peso = Number(prompt("Insira seu peso"))
let altura = Number(prompt("Insira sua altura"))

imc = peso / altura ** 2

console.log("Seu indice de massa corporal é:", imc)