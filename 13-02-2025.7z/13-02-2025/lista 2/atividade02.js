let raio = Number(prompt("Insira o valor do raio do circulo"))

console.log("A área do circulo é:", raio ** 2 * 3,14)