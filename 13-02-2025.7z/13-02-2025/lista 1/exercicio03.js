console.log("exercicio 3")

let minhaAltura = Number(prompt("Digite sua altura: "))
console.log("Altura", minhaAltura)

let sombraPredio = Number(prompt("Digite a sombra do prédio: "))
console.log("A sombra do prédio", sombraPredio)

let sombraEu = Number(prompt("Digite o valor da sua sombra: "))
console.log("Sua sombra", sombraEu)

console.log("A aultura do prédio é:", minhaAltura * sombraPredio / sombraEu)