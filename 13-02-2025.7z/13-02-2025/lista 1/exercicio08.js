console.log("Atividade 8")

let valorT
let comissaoP
let comissaoPP

let salario = Number(prompt("Qual seu salário fixo:"))
let vendaDC = Number(prompt("Quantos carros vendeu:"))

comissaoP = vendaDC * 0.05
comissaoPP = 50 * vendaDC

salarioF = comissaoP + comissaoPP + salario

console.log("O seu salário é de:", salarioF)