console.log("exercicio 5")

let salario = Number(prompt("Escreva seu salário:"))
console.log("Seu salário inicial é:", salario)

let porcentagem = Number(prompt("Escreva seu reajuste de salário:"))
console.log("O percentual de reajuste é:", porcentagem, "%")

let valor

valor = salario * porcentagem / 100

let salarioFinal

salarioFinal = valor + salario

console.log("Seu salário final é", salarioFinal)