console.log("exercicio 2")

let velocidade = Number(prompt("Digite sua velocidade: "))
console.log("velocidade", velocidade)
console.log("Sua velocidade em Km/h", velocidade * 3.6)