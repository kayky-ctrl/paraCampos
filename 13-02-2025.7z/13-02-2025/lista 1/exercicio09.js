console.log("Atividade 9")

let distancia = Number(prompt("Insira a distancia"))
let velMedia = Number(prompt("Insira a velocidade media"))

litrosusados = distancia / 12

tempo = distancia / velMedia

console.log("O tempo gasto foi:", tempo, "Litros usados", litrosusados)