console.log("exercicio 6")

let brancos = Number(prompt("Informe o número total de brancos "))
console.log("O total de brancos é:", brancos)

let nulos = Number(prompt("Informe o número total de nulos "))
console.log("O total de nulos é:", nulos)

let validos = Number(prompt("Informe o número total de válidos"))
console.log("O total de validos é:", validos)

console.log("O número total de", brancos + nulos + validos)
let total = brancos + nulos + validos

let percentualB
let percentualN
let percentualV

percentualB = brancos / total
percentualN = nulos / total
percentualV = validos / total

console.log("O percentual de brancos é:", percentualB * 100)
console.log("O percentual de nulos é:", percentualN * 100)
console.log("O percentual de validos é:", percentualV * 100)

