console.log("exercicio 1")

let numero = Number(prompt( "Digite um numero"))
console.log("Número ", numero)
console.log("Antecessor:", numero - 1)
console.log("Sucessor:", numero + 1)

