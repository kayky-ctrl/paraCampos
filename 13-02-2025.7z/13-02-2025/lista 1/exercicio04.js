function processar(){
    let v1 = document.getElementById("variavel1").value;
    let v2 = document.getElementById("variavel2").value;

    let vx = v1;
    v1 = v2;
    v2 = vx;

    let exibir = document.getElementById("resultado"); 

    exibir.innerHTML ="variavel 1:" + v1 + "variavel 2:" + v2;
}