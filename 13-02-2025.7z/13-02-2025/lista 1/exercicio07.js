console.log("Atividade 7")

let carroF
let porcentagemDD
let impostos

let carro = Number(prompt("Qual o preço de fabrica do carro"))

porcentagemDD = 0.28 * carro
impostos = 0.45 * carro

carroF = carro + porcentagemDD + impostos

console.log("O valor final do carro é:", carroF)

